# Sostabazarbd Android App

এটি `Sostabazarbd`-এর একটি Android WebView wrapper project। অ্যাপটি আপনার বর্তমান ওয়েবসাইট `https://sostabazarbd.netlify.app` অ্যাপের ভেতরে খুলবে। তাই ওয়েবসাইটের পণ্য, Supabase ও WhatsApp অর্ডার ব্যবস্থা সাইটে যেভাবে কাজ করে, অ্যাপেও সেভাবেই ব্যবহৃত হবে।

## APK তৈরি — শুধু Android মোবাইল দিয়ে

1. ZIP ফাইলটি extract করুন (Android-এ Files/ZArchiver ব্যবহার করতে পারেন)।
2. GitHub-এ একটি নতুন repository তৈরি করুন, যেমন `Sostabazarbd-Android-Project`।
3. এই ZIP-এর ফাইলগুলো repository-তে upload করুন। `.github/workflows/android.yml` ফাইলটিও রাখতে হবে।
4. GitHub repository-তে **Actions** tab খুলুন। যদি workflow অনুমতি চায়, সেটি enable করুন।
5. **Build Sostabazarbd APK** workflow নির্বাচন করে **Run workflow** চাপুন।
6. Build সফল হলে workflow run-এর নিচে **Artifacts** থেকে `Sostabazarbd-debug-apk` ডাউনলোড করুন।
7. ZIP artifact extract করে `app-debug.apk` ফাইল Android-এ খুলে install করুন। Android-এ “Install unknown apps” অনুমতি চাইতে পারে।

## গুরুত্বপূর্ণ সীমাবদ্ধতা

- এই ZIP-এ APK আগে থেকে build করা নেই; GitHub Actions build চালানোর পর APK তৈরি হবে.
- App-টি standalone native shopping system নয়; এটি বর্তমান website-কে Android app shell-এ দেখায়.
- Website URL, Supabase policies, products table, order insertion, WhatsApp link, admin page—এসবের কাজ website/backend-এর ওপর নির্ভরশীল.
- আপনার HTML-এ থাকা `config.js` অবশ্যই website deployment-এ সঠিকভাবে থাকতে হবে.
- Supabase publishable key browser-এ ব্যবহারের জন্যই; কখনো `sb_secret_` বা service-role key client app-এ রাখবেন না.
- Android app-এর ভেতরে website খোলার জন্য ইন্টারনেট লাগবে.
